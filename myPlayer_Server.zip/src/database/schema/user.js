var mongoose = require('../db.js'),
    Schema = mongoose.Schema;

var UserSchema = new Schema({
    net163_username: { type: String },                     //用户账号
    net163_userpwd: { type: String },                      //密码
    net163_userid: { type: String },
    net163_usercookie: { type: String },            //cookie
    qq_usercookie: { type: String },
    logindate: { type: Date }                       //最近登录时间
});

module.exports = mongoose.model('User', UserSchema);