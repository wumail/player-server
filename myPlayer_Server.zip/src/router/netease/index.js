
const express = require('express');
const userController = require('@c/userController.js');
const router = express.Router();
const { login_cellphone,
    song_url,
    playlist_detail,
    user_playlist,
    search,
    check_music,
    mv_detail,
    mv_url,
    lyric,
    search_hot,
    song_detail
} = require('NeteaseCloudMusicApi')

//18190004277 wsad241241
async function userLogin({ phone, password }) {
    try {
        const result = await login_cellphone({
            phone,
            password
        })
        // console.log(result.body)
        const data = result.body;
        const queryData = {
            net163_username: data.account.userName,
            net163_userpwd: password,
            net163_userid: `${data.account.id}`,
            net163_usercookie: data.cookie,
            qq_usercookie: '',
        }
        const ifexist = userController.select(
            {
                net163_username: `${data.account.userName}`,
            }
        )
        ifexist.exec().then((result) => {
            // console.log(result);
            // console.log(queryData);
            // Prints "Space Ghost is a talk show host."
            if (!result) {
                userController.insert(
                    queryData
                )
            } else {
                userController.update(
                    result,
                    queryData
                )
            }
        }).catch((err) => {
            console.log(err);
        })
    } catch (error) {
        console.log(error)
    }
}

/*
let request = req.body;
if (request.id) {

} else {
    res.status(404).send('请检查是否传入数据无误');
}
*/
router.get("/", function (req, res, next) {
    const data = {
        code: 200,
        msg: "OK",
        data: "Hello Node Server"
    };
    res.json(data);
})

router.post('/login', function (req, res, next) {
    // console.log(req);
    let request = req.body;
    if (request.phone && request.password) {
        userLogin({
            phone: request.phone,
            password: request.password
        })
        res.json('yes');
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
})

//星星堆漫天
router.post('/search', function (req, res, next) {
    let request = req.body;
    if (request.keywords) {
        search({ keywords: request.keywords }).then((response) => {
            const arr = response.body.result.songs;
            res.send(arr)
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
})

router.post('/post', function (req, res, next) {
    res.json(req.body)
})

//1_18190004277
router.post('/playlist', function (req, res, next) {
    let request = req.body;
    /*
    if (request.username) {
        userController.select(
            {
                net163_username: request.username || "1_18190004277",
            }
        ).exec().then((result) => {
            // Prints "Space Ghost is a talk show host."
            user_playlist({
                uid: result.net163_userid
            }).then((response) => {
                res.send(response.body)
            })
        }).catch((err) => {
            console.log(err);
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
    */
    userController.select(
        {
            net163_username: request.username || "1_18190004277",
        }
    ).exec().then((result) => {
        // Prints "Space Ghost is a talk show host."
        user_playlist({
            uid: result.net163_userid
        }).then((response) => {
            res.send(response.body)
        })
    }).catch((err) => {
        console.log(err);
    })
})

// 3198824474
router.post('/playlist_detail', function (req, res, next) {
    let request = req.body;
    if (request.id) {
        playlist_detail({
            id: request.id
        }).then((response) => {
            res.send(response.body)
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
})

//316103
router.post('/song_url', function (req, res, next) {
    let request = req.body;
    /*
    if (request.id) {
        const reqData = {
            id: request.id
        }
        check_music({
            id: reqData.id
        }).then((response) => {
            if (response.body.success) {
                userController.select(
                    {
                        net163_username: request.id || "1_18190004277",
                    }
                ).exec().then((result) => {
                    song_url({
                        id: reqData.id,
                        cookie: result.net163_usercookie
                    }).then((songRes) => {
                        res.send(songRes)
                    }).catch((err) => {
                        res.send(err)
                    })
                })
            } else {
                res.send(response.body.message)
            }
        }).catch((err) => {
            res.send(err)
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
    */
    const reqData = {
        id: request.id
    }
    check_music({
        id: reqData.id
    }).then((response) => {
        if (response.body.success) {
            userController.select(
                {
                    net163_username: request.username || "1_18190004277",
                }
            ).exec().then((result) => {
                song_url({
                    id: reqData.id,
                    cookie: result.net163_usercookie
                }).then((songRes) => {
                    res.send(songRes)
                }).catch((err) => {
                    res.send(err)
                })
            })
        } else {
            res.send(response.body.message)
        }
    }).catch((err) => {
        res.send(err)
    })
})

router.post('/song_detail', function (req, res, next) {
    let request = req.body;
    song_detail({
        ids: request.id
    }).then((response) => {
        res.send(response)
    }).catch((err) => {
        res.send(err)
    });
})

//10930449
router.post('/mv', function (req, res, next) {
    let request = req.body;
    if (request.mvid) {
        const data = {
            mvid: request.mvid
        }
        mv_detail(data).then((result) => {
            body = result.body;
            mv_url({
                id: body.data.id
            }).then((response) => {
                res.send(response)
            }).catch((err) => {
                res.send(err)
            })
        }).catch((err) => {
            res.send(err)
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
})

// 4237846
// 316103
router.post('/lyric', function (req, res, next) {
    let request = req.body;
    if (request.id) {
        const data = {
            id: request.id
        }
        lyric(data).then((response) => {
            res.send(response.body)
        }).catch((err) => {
            res.send(err)
        })
    } else {
        res.status(404).send('请检查是否传入数据无误');
    }
})

router.post('/hot', function (req, res, next) {
    search_hot().then((response) => {
        res.send(response)
    })
})

module.exports = router;